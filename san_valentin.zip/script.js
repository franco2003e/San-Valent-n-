function showGift() {
    document.getElementById("gift").classList.remove("hidden");
}
